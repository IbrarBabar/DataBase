software required-----    	1)wamp   2) visual Studio Code or any other software which suits you. 
First unzip the folder.
Simply open LMS folder.
Run lms.sql file on wamp.
copy the LMS folder into your wamp server directory (www) and paste LMS Folder in www directory.
Now open the LMS folder through visual studio code.
And run using (http://localhost/lms/signup.php)
